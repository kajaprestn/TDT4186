#!/bin/bash

for i in {1..10}
do
  echo "Run #$i"
  time sh load.sh
done


