#include "kernel/syscall.h"
#include "kernel/types.h"
#include "user/user.h"


int main(int argc, char *argv[]) {
    ps();
    return 0;
}
